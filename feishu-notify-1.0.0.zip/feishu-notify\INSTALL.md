# Feishu Notify Skill - Distribution Package

This is a portable Claude Code skill for sending Feishu notifications.

## Quick Install

### Method 1: Run Installer (Recommended)

1. Right-click `install.ps1` and select "Run with PowerShell"
2. Enter your Feishu webhook URL when prompted
3. Restart Claude Code

### Method 2: Manual Install

1. Copy the entire `feishu-notify` folder to:
   ```
   C:\Users\<YourUsername>\.claude\skills\
   ```

2. Create `C:\Users\<YourUsername>\.claude\.env` with:
   ```
   FEISHU_WEBHOOK_URL=https://open.feishu.cn/open-apis/bot/v2/hook/YOUR_WEBHOOK_ID
   ```

3. Restart Claude Code

## Get Webhook URL

1. Open Feishu/Lark app
2. Go to target group → Settings → Bots
3. Add Bot → Custom Bot
4. Copy the webhook URL

## Usage

In Claude Code conversation, say:
- "通知我" / "发通知" (Chinese)
- "notify me" / "send notification" (English)

Notification format: `ProjectFolder - YourMessage`

## Files

- `SKILL.md` - Skill definition
- `README.md` - Documentation
- `install.ps1` - Automated installer
- `.env.example` - Configuration template
- `scripts/send_notification.ps1` - Notification script

## Requirements

- Windows with PowerShell 5.1+
- Claude Code
- Feishu/Lark webhook access

## Support

For issues or questions, see README.md
