param(
    [string]$Message = "Claude Code task completed"
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# Find .env file - check multiple locations
$envLocations = @(
    (Join-Path $PSScriptRoot ".env"),
    (Join-Path $PSScriptRoot "..\.env"),
    (Join-Path $env:USERPROFILE ".claude\.env"),
    "D:\CustomCode\.env"
)

$envFile = $null
foreach ($loc in $envLocations) {
    if (Test-Path $loc) {
        $envFile = $loc
        break
    }
}

if (-not $envFile) {
    Write-Error "ENV file not found. Please create .env file with FEISHU_WEBHOOK_URL in one of these locations: $($envLocations -join ', ')"
    exit 1
}

$webhookUrl = ""
Get-Content $envFile -Encoding UTF8 | ForEach-Object {
    if ($_ -match '^\s*FEISHU_WEBHOOK_URL\s*=\s*(.+)\s*$') {
        $webhookUrl = $Matches[1].Trim()
    }
}

if ([string]::IsNullOrWhiteSpace($webhookUrl) -or $webhookUrl -eq "YOUR_WEBHOOK_URL_HERE") {
    Write-Error "Please configure FEISHU_WEBHOOK_URL in $envFile"
    exit 1
}

$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

$bodyObj = @{
    msg_type = "interactive"
    card = @{
        header = @{
            title = @{
                tag = "plain_text"
                content = "Claude Code"
            }
            template = "blue"
        }
        elements = @(
            @{
                tag = "div"
                text = @{
                    tag = "plain_text"
                    content = $Message
                }
            }
            @{
                tag = "div"
                text = @{
                    tag = "plain_text"
                    content = $timestamp
                }
            }
        )
    }
}

$body = $bodyObj | ConvertTo-Json -Depth 10

try {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
    $response = Invoke-RestMethod -Uri $webhookUrl -Method Post -ContentType "application/json; charset=utf-8" -Body $bytes
    if ($response.code -eq 0 -or $response.StatusMsg -eq "success") {
        Write-Output "Notification sent successfully [$timestamp]"
    } else {
        Write-Error "Feishu API error: $($response | ConvertTo-Json)"
        exit 1
    }
} catch {
    Write-Error "Send failed: $_"
    exit 1
}
