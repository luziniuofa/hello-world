---
name: feishu-notify
description: 发送飞书通知。当用户说"通知我"、"发通知"、"notify me"、"send notification"时触发此技能，发送一条飞书消息到配置的 webhook。
---

# 飞书通知

当用户请求发送通知时，使用此技能发送飞书消息。

## 触发关键词

当用户消息中包含以下关键词时应使用此技能：
- "通知我"
- "发通知"
- "notify me"
- "send notification"

## 指令

当触发此技能时，执行以下步骤：

1. **构造通知内容**：格式为 `项目文件夹名 - 用户触发通知时的那条消息原文`。
   - 项目文件夹名：取当前工作目录的最后一级文件夹名（例如 `D:\Projects\MyApp` 则取 `MyApp`）
   - 消息内容：用户说出触发关键词的那条完整消息（不是对话摘要，是原文）

2. **发送通知**（**只执行一次，绝对不要重复调用**）：

使用 PowerShell 的 `-Command` 模式执行，让 PowerShell 内部展开环境变量：

```bash
powershell -ExecutionPolicy Bypass -Command '& "$env:USERPROFILE\.claude\skills\feishu-notify\scripts\send_notification.ps1" -Message "项目文件夹名 - 用户消息原文"'
```

**重要提示**：
- 整个命令用单引号包裹（防止 Bash 解释 `$env`）
- 消息内容用双引号包裹
- 如果消息中包含双引号，需要转义为 `\"`
- 这个命令在任何 Windows 用户环境下都能自动找到正确的脚本路径

3. **报告结果**：告诉用户通知是否发送成功。

## 重要规则

- **每次只发送一条通知**，绝对不能重复发送
- 不要在一次触发中多次调用发送脚本
- 如果脚本报错，告知用户错误信息，不要重试
