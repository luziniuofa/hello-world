# Feishu Notify Skill

Send Feishu (Lark) notifications from Claude Code conversations.

## Features

- Trigger notifications with keywords: "通知我", "发通知", "notify me", "send notification"
- Notification format: `ProjectFolder - UserMessage`
- Supports Chinese and English messages
- Single notification per trigger (no duplicates)

## Installation

### 1. Copy Skill Files

Copy the entire `feishu-notify` folder to your Claude Code skills directory:

```
Windows: C:\Users\<YourUsername>\.claude\skills\feishu-notify\
macOS/Linux: ~/.claude/skills/feishu-notify/
```

### 2. Configure Webhook URL

Create a `.env` file in one of these locations:

- `C:\Users\<YourUsername>\.claude\.env` (recommended)
- Or in the skill directory: `C:\Users\<YourUsername>\.claude\skills\feishu-notify\.env`

Add your Feishu webhook URL:

```
FEISHU_WEBHOOK_URL=https://open.feishu.cn/open-apis/bot/v2/hook/YOUR_WEBHOOK_ID
```

You can copy `.env.example` as a template.

### 3. Get Feishu Webhook URL

1. Open Feishu/Lark app
2. Go to the group where you want to receive notifications
3. Click group settings → Bots → Add Bot → Custom Bot
4. Copy the webhook URL

### 4. Restart Claude Code

Restart Claude Code to load the new skill.

## Usage

In any conversation, say one of these keywords:

- "通知我" or "发通知" (Chinese)
- "notify me" or "send notification" (English)

Claude will send a notification to your configured Feishu group with the format:

```
ProjectFolderName - Your trigger message
```

## File Structure

```
feishu-notify/
├── SKILL.md                    # Skill definition
├── README.md                   # This file
├── .env.example                # Environment variable template
└── scripts/
    └── send_notification.ps1   # PowerShell notification script
```

## Troubleshooting

### "ENV file not found"

Create a `.env` file in `C:\Users\<YourUsername>\.claude\.env` with your webhook URL.

### "Please configure FEISHU_WEBHOOK_URL"

Make sure your `.env` file contains a valid webhook URL (not the placeholder).

### Encoding issues

The script uses UTF-8 encoding. If you see garbled characters, make sure your PowerShell console supports UTF-8.

## Requirements

- Windows with PowerShell 5.1 or later
- Claude Code
- Feishu/Lark account with webhook access

## License

MIT
