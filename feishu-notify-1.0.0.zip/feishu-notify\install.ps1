# Feishu Notify Skill Installer for Windows
# Run this script to install the skill

param(
    [string]$WebhookUrl = ""
)

$ErrorActionPreference = "Stop"

Write-Host "=== Feishu Notify Skill Installer ===" -ForegroundColor Cyan
Write-Host ""

# Check if running on Windows
if ($PSVersionTable.Platform -and $PSVersionTable.Platform -ne "Win32NT") {
    Write-Error "This installer is for Windows only."
    exit 1
}

# Get skill source directory (where this installer is located)
$sourceDir = $PSScriptRoot
$skillName = "feishu-notify"

# Target directory
$targetDir = Join-Path $env:USERPROFILE ".claude\skills\$skillName"

Write-Host "Source: $sourceDir" -ForegroundColor Gray
Write-Host "Target: $targetDir" -ForegroundColor Gray
Write-Host ""

# Check if skill already exists
if (Test-Path $targetDir) {
    $response = Read-Host "Skill already exists. Overwrite? (y/N)"
    if ($response -ne "y" -and $response -ne "Y") {
        Write-Host "Installation cancelled." -ForegroundColor Yellow
        exit 0
    }
    Remove-Item $targetDir -Recurse -Force
}

# Create target directory
Write-Host "Creating skill directory..." -ForegroundColor Green
New-Item -ItemType Directory -Path $targetDir -Force | Out-Null

# Copy files
Write-Host "Copying skill files..." -ForegroundColor Green
Copy-Item -Path "$sourceDir\SKILL.md" -Destination $targetDir -Force
Copy-Item -Path "$sourceDir\README.md" -Destination $targetDir -Force
Copy-Item -Path "$sourceDir\.env.example" -Destination $targetDir -Force

# Copy scripts directory
$scriptsDir = Join-Path $targetDir "scripts"
New-Item -ItemType Directory -Path $scriptsDir -Force | Out-Null
Copy-Item -Path "$sourceDir\scripts\send_notification.ps1" -Destination $scriptsDir -Force

Write-Host "Skill files copied successfully." -ForegroundColor Green
Write-Host ""

# Configure webhook URL
$envFile = Join-Path $env:USERPROFILE ".claude\.env"

if (-not $WebhookUrl) {
    Write-Host "Please enter your Feishu Webhook URL:" -ForegroundColor Yellow
    Write-Host "(Get it from: Feishu Group -> Settings -> Bots -> Add Bot -> Custom Bot)" -ForegroundColor Gray
    $WebhookUrl = Read-Host "Webhook URL"
}

if ([string]::IsNullOrWhiteSpace($WebhookUrl)) {
    Write-Host ""
    Write-Host "No webhook URL provided. You can configure it later in:" -ForegroundColor Yellow
    Write-Host "  $envFile" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Add this line:" -ForegroundColor Gray
    Write-Host "  FEISHU_WEBHOOK_URL=your_webhook_url_here" -ForegroundColor Gray
} else {
    Write-Host "Configuring webhook URL..." -ForegroundColor Green

    # Check if .env already exists
    if (Test-Path $envFile) {
        # Check if FEISHU_WEBHOOK_URL already exists
        $content = Get-Content $envFile -Raw
        if ($content -match 'FEISHU_WEBHOOK_URL=') {
            # Replace existing URL
            $content = $content -replace 'FEISHU_WEBHOOK_URL=.*', "FEISHU_WEBHOOK_URL=$WebhookUrl"
            Set-Content -Path $envFile -Value $content -NoNewline
        } else {
            # Append new URL
            Add-Content -Path $envFile -Value "`nFEISHU_WEBHOOK_URL=$WebhookUrl"
        }
    } else {
        # Create new .env file
        Set-Content -Path $envFile -Value "FEISHU_WEBHOOK_URL=$WebhookUrl"
    }

    Write-Host "Webhook URL configured in: $envFile" -ForegroundColor Green
}

Write-Host ""
Write-Host "=== Installation Complete ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Restart Claude Code to load the skill" -ForegroundColor White
Write-Host "2. In any conversation, say: '通知我' or 'notify me'" -ForegroundColor White
Write-Host ""
Write-Host "For more information, see: $targetDir\README.md" -ForegroundColor Gray
